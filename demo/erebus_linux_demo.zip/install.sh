#!/bin/sh

erebus_directory=$HOME/Games/Erebus

if [ ! -d $erebus_directory ]; then
	mkdir -p $erebus_directory
fi

cp -fr erebus_demo.x86_64 $erebus_directory/erebus_demo.x86_64
cp -fr erebus_demo.pck $erebus_directory/erebus_demo.pck
cp -fr erebus.png $HOME/.icons/erebus.png
cp -fr erebus-demo.desktop $HOME/.local/share/applications/erebus-demo.desktop
chmod u+x $HOME/.local/share/applications/erebus-demo.desktop
